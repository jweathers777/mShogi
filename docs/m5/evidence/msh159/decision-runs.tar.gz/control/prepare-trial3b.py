from pathlib import Path
import difflib,json,hashlib
base=Path('/tmp/msh159/trial3-eval.rs').read_text();s=base.replace('    let controls_front = defender.sq == front || defender.attacks & bit(front) != 0;','''    // A bishop cannot cheaply take a pawn advancing onto a protected square.
    // Promotion differs: trading the bishop for the new queen remains useful.
    // Physical occupation prevents a forward pawn move regardless of support.
    let promotion_front = front.rank() == if pawn.piece.color == Color::White { 7 } else { 0 };
    let controls_front = defender.sq == front
        || (defender.attacks & bit(front) != 0
            && (promotion_front || f.attacks[own] & bit(front) == 0));''')
idx=s.index('    #[test]\n    fn independently_derived_term_arithmetic')
s=s[:idx]+'''    #[test]
    fn bishop_restriction_respects_protected_intermediate_landing() {
        // Bc4 controls a6, but Kb6 protects the advancing pawn. Black d5
        // protects the bishop in both roots so the security guard is held fixed.
        let protected = "7k/7p/1K6/P2p4/2b5/8/8/6B1 w - - 0 1";
        let unprotected = "7k/7p/8/P2p4/2b5/2K5/8/6B1 w - - 0 1";
        // Promotion may trade a pawn for a bishop despite king protection.
        let promotion = "1K5k/P2p4/2b5/8/8/8/8/6B1 w - - 0 1";
        // Ba6 physically blocks a5-a6 even though Kb6 protects a6.
        let occupied = "7k/1p5p/bK6/P7/8/8/8/8/6B1 w - - 0 1";
        for (fen, rank, expected) in [
            (protected, 4, false),
            (unprotected, 4, true),
            (promotion, 6, true),
            (occupied, 4, true),
        ] {
            let p = position(fen);
            let f = Features::new(&p);
            let pawn = f.men.iter().find(|m| m.sq == Square::new(0, rank).unwrap()).unwrap();
            assert_eq!(secure_bishop_restriction(&f, pawn, Square::new(0, rank + 1).unwrap()), expected, "{fen}");
            let mirror = reflect(&p);
            let mf = Features::new(&mirror);
            let mp = mf.men.iter().find(|m| m.sq == Square::new(0, 7 - rank).unwrap()).unwrap();
            assert_eq!(secure_bishop_restriction(&mf, mp, Square::new(0, 6 - rank).unwrap()), expected);
        }
        let advance = "a5a6".parse().unwrap();
        assert!(position(protected).legal_actions().contains(&advance));
        assert!(!position(occupied).legal_actions().contains(&advance));
    }

'''+s[idx:]
# Correct literal board to eight ranks.
s=s.replace('7k/1p5p/bK6/P7/8/8/8/8/6B1','7k/1p5p/bK6/P7/8/8/8/6B1')
Path('/tmp/msh159/trial3b-eval.rs').write_text(s)
Path('/tmp/msh159/trial3b-vs-trial3.patch').write_text(''.join(difflib.unified_diff(base.splitlines(True),s.splitlines(True),fromfile='trial3-eval.rs',tofile='trial3b-eval.rs')))
# Apply only the exact race delta relative to original baseline. SequenceMatcher
# replacements are verified against the bishop source, preventing silent overlap.
original=Path('/tmp/msh159/trial1-baseline-eval.rs').read_text();race=Path('/tmp/msh159/trial2-built-eval.rs').read_text()
a=original.splitlines(True);b=race.splitlines(True);merged=s;changes=[]
for tag,i,j,k,l in difflib.SequenceMatcher(None,a,b,autojunk=False).get_opcodes():
 if tag=='equal':continue
 old=''.join(a[i:j]);new=''.join(b[k:l])
 if old:
  assert merged.count(old)==1,(tag,i,j,merged.count(old));merged=merged.replace(old,new,1)
 else:
  # Insert using nearest baseline line anchor; anchors must be unique.
  anchor=''.join(a[i:i+4]);assert merged.count(anchor)==1,(i,anchor,merged.count(anchor));merged=merged.replace(anchor,new+anchor,1)
 changes.append({'tag':tag,'baseline_lines':[i,j],'race_lines':[k,l]})
Path('/tmp/msh159/combined-eval.rs').write_text(merged)
Path('/tmp/msh159/combined-vs-trial3b.patch').write_text(''.join(difflib.unified_diff(s.splitlines(True),merged.splitlines(True),fromfile='trial3b-eval.rs',tofile='combined-eval.rs')))
meta={'builds_tests_engines':'NOT RUN','repo_edits':False,'merge':'verified unique baseline replacement/insertion anchors for every race-only diff opcode','race_changes':changes,'sha256':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in map(Path,['/tmp/msh159/trial3b-eval.rs','/tmp/msh159/combined-eval.rs','/tmp/msh159/trial2-built-eval.rs'])}}
Path('/tmp/msh159/trial3b-metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
