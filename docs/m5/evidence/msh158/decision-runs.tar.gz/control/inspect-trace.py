import pathlib,json,re,sys,collections
for p in sorted(pathlib.Path(sys.argv[1]).glob('cell-*.native.jsonl')):
 if not p.stat().st_size:continue
 x=json.loads(p.read_text()); ev=x['trace']['events'];it=x['completed_depth'];print('\nROOT',x['id'],'MOVE',x['move'],'DEPTH',it,'events',len(ev),'dropped',x['trace']['dropped'])
 def clean(s):
  def a(m):
   f,t=map(int,m.groups());return chr(97+f%8)+str(1+f//8)+chr(97+t%8)+str(1+t//8)
  return re.sub(r'Action \{ from: Square\((\d+)\), to: Square\((\d+)\), promotion: None \}',a,s)
 nodes={e['node']:e for e in ev if e['kind']in ['main_enter','q_enter']}
 for e in ev:
  if e['iteration']!=it:continue
  path=e['path'];k=e['kind']
  if not path and k in ['child_return','return']or len(path)<=2 and k in ['main_enter','return','late_move_pruned','futility_pruned','main_child_search']:
   print(e['node'],path,k,clean(e['detail'])[:1000])
 print('Deepestwatchedpaths',max(map(lambda e:len(e['path']),ev)))
