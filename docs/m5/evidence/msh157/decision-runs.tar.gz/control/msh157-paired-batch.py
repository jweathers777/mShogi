import json,pathlib,subprocess,sys
runner='/tmp/msh157-runs/runner.py';left,right=map(pathlib.Path,sys.argv[1:3])
ml,mr=[json.loads((p/'manifest.json').read_text())for p in [left,right]]
assert ml['panel_sha256']==mr['panel_sha256'] and len(ml['cells'])==len(mr['cells'])
def count(p):return sum(1 for _ in (p/'runs.jsonl').open())if(p/'runs.jsonl').exists()else 0
for i in range(len(ml['cells'])):
 for out in ([left,right] if i%2==0 else [right,left]):
  n=count(out)
  if n>i:continue
  assert n==i
  with(out/'batch-controller.log').open('a')as f:
   p=subprocess.run([sys.executable,runner,'next','--out',str(out)],stdout=f,stderr=f)
  if p.returncode:raise SystemExit(p.returncode)
 if(i+1)%20==0:print(json.dumps({'paired_roots_completed':i+1,'total':len(ml['cells'])}),flush=True)
print('paired complete',flush=True)
