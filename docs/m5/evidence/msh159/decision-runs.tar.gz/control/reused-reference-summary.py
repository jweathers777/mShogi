import pathlib,json,hashlib,chess
P=pathlib.Path;d=P('/tmp/msh157-reference-initial');m=json.load(open(d/'manifest.json'));rows=[]
for q in m['queries']:
 if q['root_id'] not in ['lichess-puzzle-0UOyM','lichess-puzzle-0m5mI','lichess-puzzle-28pJK']:continue
 x=json.load(open(d/f"query-{q['query_index']:03d}.result.json"));root=m['roots'][q['root_id']];b=chess.Board(root['fen'])
 for u in root['history']:b.push_uci(u)
 assert b.fen(en_passant='fen')==root['expected_root_fen']==x['root_fen'];e=x['last_nonbound_event_matching_bestmove'];assert not x['bestmove_alignment_issue'] and not e['lowerbound'] and not e['upperbound'];assert e['pv'][0]==x['bestmove']==q['root_move'];san=b.san(chess.Move.from_uci(q['root_move']))
 for u in e['pv']:b.push_uci(u)
 assert b.fen(en_passant='fen')==e['pv_validation']['final_fen']
 rows.append({'id':q['root_id'],'move':q['root_move'],'san':san,'score':e['score'],'depth':e['depth'],'pv_san':e['pv_validation']['san'],'last_two':[{'depth':v['depth'],'score':v['score']}for v in x['last_two_distinct_depth_aligned_nonbound_events']],'full_history_plies':len(root['history']),'legal_replay':True,'query_sha256':hashlib.sha256((d/f"query-{q['query_index']:03d}.result.json").read_bytes()).hexdigest()})
P('/tmp/msh159/reused-root-reference-findings.json').write_text(json.dumps({'rows':rows,'interpretation':'Reused equal3s full-history root analysis: match actualmoves rather than historical role labels. Finite support for exf3+ overKg6, Kc3 overBd6 andQc8 overQf4. Scores are not evaluator calibration targets and do not establish exact root WDL.'},indent=2)+'\n');print('verified',len(rows))
