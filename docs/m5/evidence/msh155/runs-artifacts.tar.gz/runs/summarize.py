from pathlib import Path
import json
base=Path(__file__).parent
manifest=json.loads((base/'manifest.json').read_text())
rows=[]
for line in (base/'runs.jsonl').read_text().splitlines():
 run=json.loads(line); cell=manifest['cells'][run['index']];p=cell['root'];r=json.load(open(run['result_path'])) if run['result_path'] else {};native=r.get('result');m=native.get('move') if native else r.get('bestmove');ex=p['expectation'];label='unresolved'
 if 'root_side_categories' in ex:label='WDL_preserved' if ex['root_side_categories'].get(m)==ex['root_category'] else 'WDL_lost'
 elif 'mate_within_plies' in ex:label='mate_goal_met' if m in ex['accepted_moves'] else 'mate_goal_not_met'
 elif 'published_points' in ex:label='published_'+str(ex['published_points'][m]) if m in ex['published_points'] else 'unlisted_STS_unresolved'
 elif m in ex.get('known_disfavored_moves',[]):label='prior_reference_disfavored'
 elif m in ex.get('preferred_moves_nonexhaustive',[]):label='provisional_preferred' if 'provisional' in ex['type'] or p['id'] in ['historical-24h4','historical-34Rc5'] else 'prior_reference_supported'
 score=None;depth=None;nodes=None;inc=None
 if native:
  score={'cp_or_native_mate':native['score']};depth=native['completed_depth'];nodes=native['nodes'];last=next((i for i in reversed(native['iterations']) if i['completed']),None);inc=max(0,1-last['elapsed_us']/(native['elapsed_ms']*1000)) if last else None
 else:
  ev=r.get('last_nonbound_scored_event_matching_bestmove') or r.get('last_bestmove_matching_nonbound_scored_event')
  if ev:score=ev['info'].get('score');depth=ev['info'].get('depth');nodes=ev['info'].get('nodes')
 rows.append({'root':p['id'],'fresh':p['fresh'],'category':p['primary_category'],'engine':run['engine'],'seconds':run['seconds'],'active_seconds':run['charged_active_seconds'],'move':m,'initial_rubric':label,'score':score,'depth':depth,'nodes':nodes,'incomplete_wall_share_native':inc,'stats':native.get('stats_parsed') if native else None,'result_path':run['result_path']})
(base/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
for p in dict.fromkeys(x['root'] for x in rows):
 print(p)
 for e in ['mshogi','goldfish','oxidation']:
  print(' ',e,[(x['seconds'],x['move'],x['initial_rubric'],x['depth']) for x in rows if x['root']==p and x['engine']==e])
