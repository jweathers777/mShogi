from pathlib import Path
import difflib,json,hashlib
base=Path('/tmp/msh159/trial1b-eval.rs').read_text();s=base.replace('secure_bishop_blockade','secure_bishop_restriction').replace('let bishop_blockade =','let bishop_restriction =').replace('if bishop_blockade','if bishop_restriction')
s=s.replace('''    (defender.sq == front || defender.attacks & bit(front) != 0)''','''    let controls_front = defender.sq == front || defender.attacks & bit(front) != 0;
    let pressures_undefended_pawn = defender.attacks & bit(pawn.sq) != 0
        && f.attacks[own] & bit(pawn.sq) == 0;
    (controls_front || pressures_undefended_pawn)''')
s=s.replace('        && (distance(f.kings[own], defender.sq) > 1 || defended)\n','')
s=s.replace('// Advisory current-board control, not an endgame result or a prediction that\n// the bishop cannot be displaced. Restrict the discount to opposite bishops\n// without other pieces; king approach or a direct attack releases the guard.','''// Advisory current-board blockade or pressure on an undefended pawn, not an
// endgame result or future-tempo credit. Restrict the discount to opposite
// bishops without other pieces; unsupported king approach or a nonking attack
// releases the guard. An attacked, defended passer keeps its normal premium.''')
doc='''/// Only the extra clear-runway premium is discounted. King distance ignores
/// obstructions, opposition and future checks, so this is risk, never a race
/// proof. The bounded walk is used only for advanced, currently clear passers.
'''
s=s.replace(doc,'').replace('fn passer_runway(',doc+'fn passer_runway(')
idx=s.index('    #[test]\n    fn independently_derived_term_arithmetic')
s=s[:idx]+'''    #[test]
    fn bishop_pressure_requires_present_attack_on_undefended_passer() {
        // Bc1 attacks e3 but neither e2 nor its promotion square e1.
        // Black f4 defends e3 in the second fixture, so pressure is insufficient.
        for (fen, rank, expected) in [
            ("8/8/6k1/7b/1K6/4p3/P7/2B5 b - - 0 1", 2, true),
            ("8/8/6k1/7b/1K3p2/4p3/P7/2B5 b - - 0 1", 2, false),
            ("8/8/6k1/7b/1K6/8/P3p3/2B5 b - - 0 1", 1, false),
        ] {
            let p = position(fen);
            let f = Features::new(&p);
            let pawn = f.men.iter().find(|m| m.sq == Square::new(4, rank).unwrap()).unwrap();
            assert_eq!(secure_bishop_restriction(&f, pawn, Square::new(4, rank - 1).unwrap()), expected);
            let mirror = reflect(&p);
            let mf = Features::new(&mirror);
            let mp = mf.men.iter().find(|m| m.sq == Square::new(4, 7 - rank).unwrap()).unwrap();
            assert_eq!(secure_bishop_restriction(&mf, mp, Square::new(4, 8 - rank).unwrap()), expected);
            assert_eq!(evaluate(&p).black.pawns, evaluate(&mirror).white.pawns);
        }
    }

    #[test]
    fn bishop_pressure_matched_development_continuation_ranking() {
        // Finite reference preference, not a rules/WDL oracle: compare the two
        // legal White replies at the same after-e3 development state. This is
        // a diagnostic static-ranking target, not evidence of a root benefit.
        let fen = "8/8/6k1/P2p3p/2bP1PpP/B1K1p1P1/8/8 w - - 0 49";
        let mut bishop = AdjudicatedGame::from_fen(fen, ClaimPolicy::ExplicitOnly).unwrap();
        let mut king = bishop.clone();
        bishop.apply("a3c1".parse().unwrap()).unwrap();
        king.apply("c3c2".parse().unwrap()).unwrap();
        assert!(evaluate(bishop.position()).score_for(Color::White)
            > evaluate(king.position()).score_for(Color::White));
    }

'''+s[idx:]
Path('/tmp/msh159/trial3-eval.rs').write_text(s)
Path('/tmp/msh159/trial3-vs-trial1b.patch').write_text(''.join(difflib.unified_diff(base.splitlines(True),s.splitlines(True),fromfile='trial1b-eval.rs',tofile='trial3-eval.rs')))
Path('/tmp/msh159/trial3-metadata.json').write_text(json.dumps({'base':'trial1b-eval.rs','base_sha256':hashlib.sha256(base.encode()).hexdigest(),'source_sha256':hashlib.sha256(s.encode()).hexdigest(),'build':'not run','tests':'not run','engines':'not run','repo_edits':False,'race_feature':False},indent=2)+'\n')
