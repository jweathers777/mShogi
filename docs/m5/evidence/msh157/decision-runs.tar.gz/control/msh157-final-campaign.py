import pathlib,json,time,subprocess,sys
R=pathlib.Path('/tmp/msh157-runs');runner=str(R/'runner.py');python=sys.executable
while True:
 rows=[json.loads(s)for s in(R/'candidate-development/runs.jsonl').read_text().splitlines()]
 assert all(r['status']==0 for r in rows),'candidate failure; do not continue'
 if len(rows)==160:break
 time.sleep(2)
for label,panel,seconds,allowance in [('heldout','/tmp/msh156-data/heldout.json',5,430),('fast',str(R/'fast-panel.json'),1,65)]:
 outs=[]
 for name,binary,revision in [('predecessor','/tmp/msh157-bin/predecessor','d53f34413d808dc2b727a06a770b92f24191eabf'),('candidate','/tmp/msh157-bin/native-candidate','3b523149e55e990ae4dbb684a9ff724c6820b235')]:
  out=str(R/(label+'-'+name));outs.append(out)
  subprocess.run([python,runner,'prepare','--panel',panel,'--binary',binary,'--out',out,'--source-revision',revision,'--registry',str(R/'registry.json'),'--seconds',str(seconds),'--budget',str(allowance)],check=True)
 subprocess.run([python,'/tmp/msh157-paired-batch.py',*outs],check=True)
print('final campaign complete',flush=True)
