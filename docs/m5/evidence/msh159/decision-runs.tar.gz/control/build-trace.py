from pathlib import Path
import subprocess,hashlib,json,shutil
p=Path('/tmp/msh159');names=['crates/mshogi-search/src/chess_conventional.rs','crates/mshogi-search/examples/chess_frontier_profile.rs'];original={n:Path(n).read_bytes()for n in names};rec={}
try:
 Path(names[0]).write_bytes(Path('/tmp/msh158/experiment4-search.rs').read_bytes())
 subprocess.run(['git','apply','--include='+names[1],'/tmp/msh158/trace.patch'],check=True)
 for n in names:
  dst=p/('traced-'+Path(n).name);dst.write_bytes(Path(n).read_bytes());rec[n]=hashlib.sha256(dst.read_bytes()).hexdigest()
 rec['eval_source_sha256']=hashlib.sha256(Path('crates/mshogi-search/src/chess_conventional_eval.rs').read_bytes()).hexdigest()
 subprocess.run(['cargo','build','--release','--locked','--offline','-p','mshogi-search','--example','chess_frontier_profile'],check=True)
 shutil.copy('target/release/examples/chess_frontier_profile',p/'bin/traced-combined');rec['binary_sha256']=hashlib.sha256((p/'bin/traced-combined').read_bytes()).hexdigest()
finally:
 for n,b in original.items():Path(n).write_bytes(b)
(p/'trace-build.json').write_text(json.dumps(rec,indent=2)+'\n')
subprocess.run(['cargo','build','--release','--locked','--offline','-p','mshogi-search','--example','chess_frontier_profile'],check=True)
assert hashlib.sha256(Path('target/release/examples/chess_frontier_profile').read_bytes()).hexdigest()==json.load(open(p/'combined-build.json'))['binary_sha256'],'restored plain binary differs'
