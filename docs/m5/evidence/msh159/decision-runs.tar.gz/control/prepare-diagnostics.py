import json,pathlib,copy,chess,hashlib
P=pathlib.Path;out=P('/tmp/msh159');roots={r['source_id']:r for r in json.load(open(out/'failures.json'))};rows=[]
def derive(parent,label,moves):
 r=copy.deepcopy(roots[parent]);r['id']=parent+'-'+label;r['parent_id']=roots[parent]['id'];r['history']+=moves.split();b=chess.Board(r['fen'])
 for u in r['history']:b.push_uci(u)
 assert b.is_valid();r['expected_root_fen']=b.fen(en_passant='fen');r['source_root_fen']=r['expected_root_fen'];r['diagnostic_suffix']=moves.split();r['original_root_side']='white'if parent=='0m5mI'else'black';return r
for parent in roots:rows.append(derive(parent,'root',''))
pawn='e4f3 g2f3 h7h6 f3e3 h6g5 e3d4 g5g4 d4c5 g4g3'
for label,path in [('capture',pawn),('cached-endpoint',pawn+' c5b6 g7g5 b6a6 g5g4 a6b5 g3f4'),('other-leaf','e4f3 g2f3 g7g6 g3g4 h7h6 f3e3 h6g5 e3d4 g5g4 d4c5 g6g5 c5b6 a6a5 b4a5 g4f3'),('closed','h7g6 g3g4'),('open','e4f3 g2f3'),('route','e4f3 g2f3 h7h6')]:rows.append(derive('0UOyM',label,path))
bishop='b2c3 f5f4 e3f4 e4e3'
for label,path in [('after-e3',bishop),('bc1',bishop+' a3c1'),('kc2',bishop+' c3c2'),('after-e2',bishop+' a3c1 e3e2'),('bd2',bishop+' a3c1 e3e2 c1d2'),('kd2',bishop+' a3c1 e3e2 c3d2'),('ba6',bishop+' a3c1 e3e2 c1d2 c4a6'),('kb4',bishop+' a3c1 e3e2 c1d2 c4a6 c3b4')]:rows.append(derive('0m5mI',label,path))
for label,path in [('qf4','f5f4'),('qc8','f5c8')]:rows.append(derive('28pJK',label,path))
(out/'static-panel.json').write_text(json.dumps(rows,indent=2)+'\n')
selected=[r for r in rows if r['id']in ['0m5mI-after-e3','0m5mI-after-e2','0UOyM-open']];p=out/'reference-panel-initial.json';p.write_text(json.dumps(selected,indent=2)+'\n');moves={'0m5mI-after-e3':['a3c1','c3c2'],'0m5mI-after-e2':['c1d2','c3d2'],'0UOyM-open':['h7h6','g7g6']};queries=[]
for r in selected:
 for role,move in zip(['predecessor','candidate'],moves[r['id']]):queries.append(dict(query_index=len(queries),root_id=r['id'],root_move=move,seconds=3,role=role))
x={'state':'FROZEN_FINAL_REFERENCE_PAIRS','panel_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'nominal_active_seconds':len(queries)*3,'queries':queries,'role_note':'Existing paired driver uses predecessor/candidate labels; these denote first/second diagnostic alternatives, NOT engine versions. Judge actual rootmove.'};(out/'reference-initial-plan.json').write_text(json.dumps(x,indent=2)+'\n')
