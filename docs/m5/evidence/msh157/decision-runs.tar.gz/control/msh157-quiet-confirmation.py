import pathlib,subprocess,sys
R=pathlib.Path('/tmp/msh157-runs');outs=[]
for name,binary,revision in [('predecessor','/tmp/msh157-bin/predecessor','d53f34413d808dc2b727a06a770b92f24191eabf'),('candidate','/tmp/msh157-bin/native-candidate','3b523149e55e990ae4dbb684a9ff724c6820b235')]:
 out=str(R/('quiet-'+name));outs.append(out)
 subprocess.run([sys.executable,str(R/'runner.py'),'prepare','--panel',str(R/'quiet-confirmation-panel.json'),'--binary',binary,'--out',out,'--source-revision',revision,'--registry',str(R/'registry.json'),'--seconds','5','--budget','115'],check=True)
subprocess.run([sys.executable,'/tmp/msh157-paired-batch.py',*outs],check=True)
