import json,pathlib,subprocess,time,hashlib,re
p=pathlib.Path('/private/tmp/msh148');positions=json.loads(pathlib.Path('docs/m5/evidence/msh147/positions.json').read_text());bins={'before':pathlib.Path('/private/tmp/msh147/diagnostic-profile'),'after':p/'candidate-profile'};source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();start=time.monotonic();fixed=[];timed=[]
def run(x,label,rep,mode,nodes):
 f=p/'input.json';f.write_text(json.dumps([x]));cmd=[str(bins[label]),str(f),'128',mode,nodes];r=subprocess.run(cmd,capture_output=True,text=True,timeout=45);assert r.returncode==0,(r.stderr,x['id']);a=json.loads(r.stdout);a.update(label=label,rep=rep);assert a['root_unchanged'] and a['pv_native_admitted'];return a
parse=lambda s:{k:int(v) for k,v in re.findall(r'(\w+): (\d+)',s)}
with (p/'fixed.jsonl').open('w') as out:
 for i,x in enumerate(positions):
  for rep in range(3):
   pair={}
   for label in (['before','after'] if (rep+i)%2==0 else ['after','before']):
    a=run(x,label,rep,'untimed','100000');out.write(json.dumps(a)+'\n');out.flush();fixed.append(a);pair[label]=a
   for k in ['result','nodes','score','completed_depth','seldepth','pv']:assert pair['before'][k]==pair['after'][k],(x['id'],rep,k)
   os,ns=parse(pair['before']['stats']),parse(pair['after']['stats']);assert all(v==ns[k] for k,v in os.items() if k not in ['q_quiet_projections','quiet_threat_moves']),(x['id'],rep,'stats')
  print('fixed-equivalent',x['id'],flush=True)
with (p/'timed.jsonl').open('w') as out:
 for i,x in enumerate(positions):
  for ms in ([1000,5000] if x['id'] in ['sts-openfiles-001','goldfish-pawn-exchange-44','goldfish-queen-rook-31','tb-7'] else [1000]):
   for label in (['before','after'] if i%2==0 else ['after','before']):
    a=run(dict(x,time_ms=ms),label,0,'timed','none');out.write(json.dumps(a)+'\n');out.flush();timed.append(a)
   print('timed',x['id'],ms,[(a['label'],a['move'],a['score'],a['completed_depth']) for a in timed[-2:]],flush=True)
with (p/'oracles.jsonl').open('w') as out:
 for x in json.loads(pathlib.Path('docs/m5/evidence/msh147/additional-endgames.json').read_text()):
  a=run(x,'after',0,'timed','none');out.write(json.dumps(a)+'\n');out.flush();category=x['tb_moves'][a['move']];expected={'win':'loss','loss':'win','draw':'draw'}[x['expected_category']];assert category==expected,(x['id'],category,expected);print('oracle-WDL',x['id'],'preserved',flush=True)
r={'source':source,'baseline_source':'0a6e8cf27e34b4b36311b09e3b3d14071d3f03bc','binary_sha256':{k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in bins.items()},'elapsed_seconds':time.monotonic()-start,'fixed_pairs':len(fixed)//2,'timed_conditions':len(timed),'oracle_cases':6,'fixed_equivalence':'all completed results/PV/work/legacy counters identical except reached quiet projections/threat admissions','method':'sequential alternated order,3fixed-work repeats/12positions; unisolated desktop; no concurrent builds/tests/matches','exit':0};(p/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(r,flush=True)
