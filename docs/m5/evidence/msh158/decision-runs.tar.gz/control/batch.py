import subprocess,sys,json,pathlib
out=pathlib.Path(sys.argv[1]);manifest=json.loads((out/'manifest.json').read_text())
for _ in manifest['cells']:
 n=len((out/'runs.jsonl').read_text().splitlines())if(out/'runs.jsonl').exists()else 0
 if n==len(manifest['cells']):break
 subprocess.run([sys.executable,'/tmp/msh158/runs/runner.py','next','--out',str(out)],check=True)
