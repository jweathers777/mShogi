import json,pathlib,subprocess,sys,time
runner='/tmp/msh157-runs/runner.py';out=pathlib.Path(sys.argv[1]);log=out/'batch-controller.log'
m=json.loads((out/'manifest.json').read_text());ledger=out/'runs.jsonl'
with log.open('a') as f:
 while True:
  n=sum(1 for _ in ledger.open()) if ledger.exists() else 0
  if n>=len(m['cells']):break
  p=subprocess.run([sys.executable,runner,'next','--out',str(out)],stdout=f,stderr=f);f.flush()
  if p.returncode:raise SystemExit(p.returncode)
  if (n+1)%20==0:print(json.dumps({'completed':n+1,'total':len(m['cells'])}),flush=True)
print('complete',flush=True)
