from pathlib import Path
p=Path('crates/mshogi-search/src/chess_conventional_eval.rs');s=p.read_text()
s=s.replace('let bishops: Vec<_> = f.men.iter().filter(|m| m.piece.kind == PieceKind::Bishop).collect();\n    if (bishops[0].sq.file() + bishops[0].sq.rank()) % 2\n        == (bishops[1].sq.file() + bishops[1].sq.rank()) % 2','let mut bishops = f.men.iter().filter(|m| m.piece.kind == PieceKind::Bishop);\n    let first = bishops.next().unwrap();\n    let second = bishops.next().unwrap();\n    if (first.sq.file() + first.sq.rank()) % 2\n        == (second.sq.file() + second.sq.rank()) % 2')
s=s.replace('let defender = bishops.iter().find(|m| m.piece.color != pawn.piece.color).unwrap();','let defender = if first.piece.color != pawn.piece.color { first } else { second };')
idx=s.index('    #[test]',s.index('mod tests {'))
s=s[:idx]+'''    #[test]
    fn bishop_blockade_discounts_only_advancement_and_is_color_symmetric() {
        // Bd2 controls e1 now; Bc1 does not. Neither bishop is attacked.
        // The black king is four squares from Bd2. Both roots have legal moves.
        let guarded = position("8/8/6k1/7b/1K6/8/P2Bp3/8 b - - 0 1");
        let future = position("8/8/6k1/7b/1K6/8/P3p3/2B5 b - - 0 1");
        assert!(!guarded.legal_moves().is_empty());
        assert!(!future.legal_moves().is_empty());
        let a = evaluate(&guarded);
        let b = evaluate(&future);
        assert_eq!(a.black.material, b.black.material);
        assert_eq!(a.black.material, 430);
        assert_eq!(a.black.placement, b.black.placement);
        // Isolated -8, retained passer base10, escort4*(3-5)=-8.
        assert_eq!(a.black.pawns.end, -6);
        assert!(b.black.pawns.end > a.black.pawns.end + 100);
        let mirrored = evaluate(&reflect(&guarded));
        assert_eq!(a.black.pawns, mirrored.white.pawns);
        assert_eq!(a.white.pawns, mirrored.black.pawns);
        assert_eq!(a.score_for(Color::Black), mirrored.score_for(Color::White));
    }

    #[test]
    fn bishop_blockade_requires_current_secure_opposite_bishop_control() {
        let guarded = "8/8/6k1/7b/1K6/8/P2Bp3/8 b - - 0 1";
        let check = |fen: &str| {
            let p = position(fen);
            let f = Features::new(&p);
            let pawn = f.men.iter().find(|m| m.sq == Square::new(4, 1).unwrap()).unwrap();
            secure_bishop_blockade(&f, pawn, Square::new(4, 0).unwrap())
        };
        assert!(check(guarded));
        for fen in [
            "8/8/6k1/7b/1K6/8/P3p3/2B5 b - - 0 1", // no current control
            "8/8/6k1/7b/1K6/8/P3p3/8 b - - 0 1", // bishop removed
            "8/8/6k1/8/1K5b/8/P2Bp3/8 b - - 0 1", // same color
            "r7/8/6k1/7b/1K6/8/P2Bp3/8 b - - 0 1", // major present
            "8/8/6k1/7b/1K6/4p3/P2Bp3/8 b - - 0 1", // pawn attacks bishop
            "8/8/8/7b/1K1k4/8/P2Bp3/8 b - - 0 1", // king close, no defense
        ] {
            assert!(!check(fen), "{fen}");
        }
        // A nearby pawn-side king does not invalidate a pawn-defended bishop,
        // but actual attack by that king does, even with pawn defense.
        assert!(check("8/8/8/7b/1K1k4/2P5/P2Bp3/8 b - - 0 1"));
        assert!(!check("8/8/8/7b/1K6/2Pk4/P2Bp3/8 b - - 0 1"));
    }

'''+s[idx:];p.write_text(s)
