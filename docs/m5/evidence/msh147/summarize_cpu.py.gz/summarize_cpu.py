"""Read sample call trees, subtract immediate children, count each sample once.
No engines are started. Inclusive role totals are separately labelled overlapping.
"""
import re,json,hashlib
from pathlib import Path
from collections import Counter
BASE=Path('/private/tmp/msh147')
def symbol(s):
 m=re.match(r'^(.*?)\s+\(in ([^)]*)\)',s)
 return m[1]+' (in '+m[2]+')' if m else s
def matches(s,words):return any(w in s for w in words)
def native(s):return 'mshogi_core5chess' in s or 'mshogi_core' in s and matches(s,['5legal','6attack','6action','8generate','13search_access'])
def key(s):return matches(s,['RepetitionIdentity','repetition_identity','update_position_hash','SearchKey','entry_index','Engine5store'])
def alloc(s):return matches(s,['libsystem_malloc','raw_vec','__rust_alloc','__rust_dealloc'])
def clock(s):return matches(s,['mach_absolute_time','clock_gettime','Instant3now','Instant7elapsed'])
def category(s):
 if alloc(s):return 'allocation_self'
 if clock(s):return 'clock_self'
 if matches(s,['_platform_mem','memcpy','memmove']):return 'memory_copy_self'
 if key(s):return 'history_identity_key_tt_self'
 if 'chess_conventional_eval' in s:return 'evaluation_self'
 if '8exchange' in s:return 'see_self'
 if native(s):return 'native_other_self'
 if 'chess_conventional' in s:return 'search_other_self'
 return 'other_self'
def parse(path):
 text=path.read_text();lines=text.split('Call graph:\n',1)[1].split('Total number in stack',1)[0].splitlines();nodes=[];stack=[]
 for line in lines:
  m=re.match(r'^([ +!:|]*)(\d+) (.*)$',line)
  if not m:continue
  indent=len(m[1]);n={'depth':indent,'count':int(m[2]),'frame':m[3],'child_total':0}
  while stack and nodes[stack[-1]]['depth']>=indent:stack.pop()
  if stack:nodes[stack[-1]]['child_total']+=n['count']
  n['parent']=stack[-1] if stack else None;nodes.append(n);stack.append(len(nodes)-1)
 residual=[];top=Counter();cats=Counter();roles=Counter();context=Counter()
 for i,n in enumerate(nodes):
  w=n['count']-n['child_total'];assert w>=0,(path,n)
  if not w:continue
  ancestors=[];j=i
  while j is not None:ancestors.append(nodes[j]['frame']);j=nodes[j]['parent']
  residual.append(w);top[symbol(n['frame'])]+=w;cats[category(n['frame'])]+=w
  q=any('quiescence' in s for s in ancestors)
  ev=any('chess_conventional_eval' in s for s in ancestors)
  se=any('8exchange' in s for s in ancestors)
  for name,flag in {
   'quiescence_any_ancestor':q,'evaluation_any_ancestor':ev,'see_any_ancestor':se,
   'native_any_ancestor':any(native(s) for s in ancestors),
   'native_turn_any_ancestor':any('SearchCursor4turn' in s for s in ancestors),
   'native_fullnode_any_ancestor':any('SearchCursor4node' in s for s in ancestors),
   'native_preview_any_ancestor':any('SearchCursor7preview' in s for s in ancestors),
   'native_push_any_ancestor':any('SearchCursor13push_with_key' in s for s in ancestors),
   'native_pop_any_ancestor':any('SearchCursor3pop' in s for s in ancestors),
   'checked_after_any_ancestor':any('checked_after' in s for s in ancestors),
   'q_checked_after_excluding_see':q and not se and any('checked_after' in s for s in ancestors),
   'mate_query_any_ancestor':any(matches(s,['contact_mate_for','queen_contact_mate','mate_threat']) for s in ancestors),
   'identity_key_tt_any_ancestor':any(key(s) for s in ancestors),
   'explicit_table_logic_any_ancestor':any(matches(s,['entry_index','Engine5store','SearchKey']) for s in ancestors),
   'native_repetition_identity_any_ancestor':any(matches(s,['RepetitionIdentity','repetition_identity']) for s in ancestors),
   'incremental_position_hash_any_ancestor':any('update_position_hash' in s for s in ancestors),
  }.items():
   if flag:roles[name]+=w
  # Allocation/clock/memmove have a physical bucket; remaining samples attach
  # to most specific observed semantic caller, before generic native/search.
  cat=category(n['frame'])
  if cat in ['allocation_self','clock_self','memory_copy_self']:context[cat]+=w
  elif se:context['see_including_native_nonalloc']+=w
  elif ev:context['evaluation_including_native_nonalloc']+=w
  elif any(key(s) for s in ancestors):context['identity_key_tt_nonalloc']+=w
  elif any(native(s) for s in ancestors):context['native_other_nonalloc']+=w
  else:context['search_other_nonalloc']+=w
 total=sum(n['count'] for n in nodes if n['parent'] is None)
 assert sum(residual)==total==sum(cats.values())==sum(context.values())
 # Independent check against sample's own collapsed self counts (>=5 only).
 collapsed=text.split('Sort by top of stack, same collapsed (when >= 5):',1)[1].split('Binary Images:',1)[0]
 checked=0
 for line in collapsed.splitlines():
  m=re.match(r'^\s+(.*?)\s+\(in ([^)]*)\)\s+(\d+)\s*$',line)
  if m:
   k=m[1]+' (in '+m[2]+')'
   assert top[k]==int(m[3]),(k,top[k],m[3]);checked+=1
 def rows(counter):return {k:{'samples':v,'percent':round(100*v/total,2)} for k,v in counter.most_common()}
 return {'file':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'sample_weight':total,'exclusive_residual_weight':sum(residual),'native_collapsed_self_symbols_crosschecked':checked,'exclusive_self_categories':rows(cats),'exclusive_context_categories':rows(context),'overlapping_ancestor_roles_do_not_sum':rows(roles),'top_self_symbols':dict(top.most_common(15))}
result={'method':'Each call-tree node count minus immediate-child count gives exclusive residual sample weight. Per-stack roles count weight once even when recursive; overlapping role totals are not additive. Exclusive bins sum to total. Collapsed self symbols crosschecked against sample own report. Symbols may inline/merge, so attribution is approximate, not exact wall time.', 'source':'0a6e8cf27e34b4b36311b09e3b3d14071d3f03bc','files':[parse(BASE/('cpu-owned-'+x+'.txt')) for x in ['sts-openfiles-001','goldfish-pawn-exchange-44','goldfish-queen-rook-31']]}
(BASE/'cpu-independent-summary.json').write_text(json.dumps(result,indent=2)+'\n')
for r in result['files']:
 print(Path(r['file']).name,r['sample_weight'],r['native_collapsed_self_symbols_crosschecked'])
 print('exclusive context',r['exclusive_context_categories'])
 print('ancestor roles',r['overlapping_ancestor_roles_do_not_sum'])
