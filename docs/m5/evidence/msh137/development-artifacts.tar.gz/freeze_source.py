import hashlib,json,subprocess,pathlib,sys
prefix=sys.argv[1]
files=subprocess.check_output(['git','diff','--name-only','--','crates'],text=True).splitlines()
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard','crates'],text=True).splitlines()
patch=subprocess.check_output(['git','diff','--binary','--','crates'])
for f in new:
 r=subprocess.run(['git','diff','--no-index','--binary','/dev/null',f],capture_output=True)
 assert r.returncode==1
 patch+=r.stdout
pathlib.Path(prefix+'-source.patch').write_bytes(patch)
manifest={'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'patch_sha256':hashlib.sha256(patch).hexdigest(),'source_files':{f:hashlib.sha256(pathlib.Path(f).read_bytes()).hexdigest() for f in sorted(set(files+new))},'profile_executable_sha256':hashlib.sha256(pathlib.Path('target/release/examples/chess_cost_profile').read_bytes()).hexdigest()}
pathlib.Path(prefix+'-source.json').write_text(json.dumps(manifest,indent=2)+'\n')
