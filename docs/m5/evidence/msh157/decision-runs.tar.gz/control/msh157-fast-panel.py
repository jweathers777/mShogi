import json,hashlib,collections
from pathlib import Path
roots=json.loads(Path('/tmp/msh156-data/development.json').read_text());chosen=[]
def rank(x):return hashlib.sha256(('MSH157-fast-screen-v1:'+x['id']).encode()).hexdigest()
for source in ['puzzle','sts','evaluation','tablebase']:
 strata=collections.defaultdict(list)
 for r in roots:
  if r['source_kind']==source:
   key=r['stratum']
   if source=='tablebase':key+=str(r['expectation']['root_wdl'])
   strata[key].append(r)
 for values in strata.values():values.sort(key=rank)
 keys=sorted(strata,key=lambda k:hashlib.sha256(k.encode()).hexdigest());picked=[]
 while len(picked)<10:
  for k in keys:
   if strata[k]:picked.append(strata[k].pop(0))
   if len(picked)==10:break
 chosen.extend(picked)
chosen.sort(key=rank)
Path('/tmp/msh157-runs/fast-panel.json').write_text(json.dumps(chosen,indent=2)+'\n')
Path('/tmp/msh157-runs/fast-selection.json').write_text(json.dumps({'method':'Deterministic source-balanced round-robin strata, hash ranking; no native outcomes consulted','source_panel_sha256':hashlib.sha256(Path('/tmp/msh156-data/development.json').read_bytes()).hexdigest(),'roots':len(chosen),'ids':[r['id'] for r in chosen],'sha256':hashlib.sha256(Path('/tmp/msh157-runs/fast-panel.json').read_bytes()).hexdigest()},indent=2)+'\n')
print('Frozen40-development-root secondary one-second screen;10 per source')
