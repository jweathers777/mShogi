from pathlib import Path
p=Path('crates/mshogi-search/src/chess_conventional_eval.rs')
s=p.read_text()
s=s.replace('let middle = 4 + 3 * advance * advance;\n                    let end = 10 + 7 * advance * advance;', '''let bishop_blockade = advance >= 3 && secure_bishop_blockade(&f, man, front);
                    let middle = if bishop_blockade { 4 } else { 4 + 3 * advance * advance };
                    let end = 10 + 7 * advance * advance;''')
s=s.replace('if blocked { end / 2 } else { end } + escort + runway\n                            - if unsafe_path { end / 4 } else { 0 },','''if bishop_blockade {
                            10 + escort
                        } else {
                            if blocked { end / 2 } else { end } + escort + runway
                                - if unsafe_path { end / 4 } else { 0 }
                        },''')
idx=s.index('fn passer_runway(')
s=s[:idx]+'''// Advisory current-board control, not an endgame result or a prediction that
// the bishop cannot be displaced. Restrict the discount to opposite bishops
// without other pieces; king approach or a direct attack releases the guard.
fn secure_bishop_blockade(f: &Features, pawn: &Man, front: Square) -> bool {
    if f.bishops != [1, 1]
        || f.men.iter().any(|m| matches!(m.piece.kind, PieceKind::Knight | PieceKind::Rook | PieceKind::Queen))
    {
        return false;
    }
    let own = side(pawn.piece.color);
    let bishops: Vec<_> = f.men.iter().filter(|m| m.piece.kind == PieceKind::Bishop).collect();
    if (bishops[0].sq.file() + bishops[0].sq.rank()) % 2
        == (bishops[1].sq.file() + bishops[1].sq.rank()) % 2
    {
        return false;
    }
    let defender = bishops.iter().find(|m| m.piece.color != pawn.piece.color).unwrap();
    let king_defends = distance(f.kings[1 - own], defender.sq) == 1;
    (defender.sq == front || defender.attacks & bit(front) != 0)
        && f.attacks[own] & bit(defender.sq) == 0
        && (distance(f.kings[own], defender.sq) > 2
            || king_defends
            || f.pawn_attacks[1 - own] & bit(defender.sq) != 0)
}

'''+s[idx:]
# parenthesize old if-expression due Rust parsing
s=s.replace('if blocked { end / 2 } else { end } + escort + runway','(if blocked { end / 2 } else { end }) + escort + runway')
p.write_text(s)
