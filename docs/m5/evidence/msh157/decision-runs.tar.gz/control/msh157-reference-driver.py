#!/usr/bin/env python3
"""prepare is read-only to engines; next requires an explicit coordinator slot release."""
import sys,pathlib,json,hashlib,time,os,signal,subprocess,resource,math,logging,fcntl,traceback,importlib.util
import chess,chess.engine
REGISTRY=pathlib.Path('/tmp/msh157-runs/registry.json')
RUNNER=pathlib.Path('/tmp/msh157-runs/runner.py')
spec=importlib.util.spec_from_file_location('native_budget',RUNNER);budget=importlib.util.module_from_spec(spec);spec.loader.exec_module(budget)
def utc():return __import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()
BINARY=pathlib.Path('/private/tmp/msh49/opponent/stockfish/stockfish-macos-universal')
PANEL=pathlib.Path('/tmp/msh156-data/development.json')
EXPECTED_PANEL='4c2dc1459b7be62201f04cb58cd7cbddc61483d8a90d9584fd16f3220bc00389'
def read(p):return json.loads(pathlib.Path(p).read_text())
def write(p,j):pathlib.Path(p).write_text(json.dumps(j,indent=2)+'\n')
def digest(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def board_for(r):
 b=chess.Board(r['fen'])
 for u in r['history']:b.push_uci(u)
 assert b.fen(en_passant='fen')==r['expected_root_fen'] and b.is_valid()
 return b
class TimedLog(logging.FileHandler):
 def __init__(self,p):super().__init__(p);self.go=None;self.best=None
 def emit(self,record):
  assert self.stream is None or self.stream.tell()<2*1024*1024,'rawUCI artifact2MB ceiling'
  s=record.getMessage()
  if ': << go ' in s:self.go=time.monotonic()
  if ': >> bestmove ' in s:self.best=time.monotonic()
  super().emit(record)
def validate(b,pv):
 x=b.copy();san=[]
 for m in pv:assert m in x.legal_moves;san.append(x.san(m));x.push(m)
 return {'san':san,'final_fen':x.fen(en_passant='fen'),'legal':True}
def worker(qfile):
 q=read(qfile);base=pathlib.Path(qfile).with_suffix('');r=q['root'];b=board_for(r);rootmove=q['query']['root_move'];limit=q['query']['seconds']
 resource.setrlimit(resource.RLIMIT_CPU,(math.ceil(limit)+4,math.ceil(limit)+5));resource.setrlimit(resource.RLIMIT_FSIZE,(128*1024*1024,128*1024*1024));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
 handler=TimedLog(str(base)+'.raw-uci.log');handler.setFormatter(logging.Formatter('%(relativeCreated).3f %(levelname)s %(message)s'));logger=logging.getLogger('chess.engine');logger.setLevel(logging.DEBUG);logger.propagate=False;logger.addHandler(handler)
 e=None;events=[];started=time.monotonic()
 try:
  e=chess.engine.SimpleEngine.popen_uci(str(BINARY),timeout=4)
  assert e.id.get('name')=='Stockfish 19',e.id
  config={k:v for k,v in {'Threads':1,'Hash':16,'SyzygyPath':'','UCI_LimitStrength':False}.items() if k in e.options};e.configure(config);e.ping()
  forced=None if rootmove is None else [chess.Move.from_uci(rootmove)];assert forced is None or forced[0] in b.legal_moves
  with e.analysis(b,chess.engine.Limit(time=limit),game=object(),root_moves=forced,info=chess.engine.INFO_ALL) as analysis:
   for info in analysis:
    pv=info.get('pv',[])
    if pv:assert forced is None or pv[0]==forced[0]
    ev={'received_process_seconds':time.monotonic()-started,**{k:info.get(k) for k in ['depth','seldepth','nodes','time','nps','hashfull','multipv'] if k in info},'lowerbound':bool(info.get('lowerbound')),'upperbound':bool(info.get('upperbound')),'pv':[m.uci() for m in pv]}
    if 'score' in info:ev['score']={'cp':info['score'].pov(b.turn).score(),'mate':info['score'].pov(b.turn).mate(),'perspective':'root_side'}
    if pv:ev['pv_validation']=validate(b,pv)
    assert sum(len(json.dumps(x)) for x in events)<2*1024*1024,'events artifact2MB ceiling'
    events.append(ev)
    with open(str(base)+'.events.jsonl','a') as f:f.write(json.dumps(ev)+'\n')
   best=analysis.wait()
  assert best.move in b.legal_moves and (forced is None or best.move==forced[0])
  assert handler.go is not None and handler.best is not None
  unbound=[x for x in events if 'score' in x and x.get('pv') and x.get('multipv',1)==1 and not x['lowerbound'] and not x['upperbound']]
  aligned=[x for x in unbound if x['pv'][0]==best.move.uci()];distinct=[];depths=set()
  for x in reversed(aligned):
   if x.get('depth') not in depths:distinct.append(x);depths.add(x.get('depth'))
   if len(distinct)==2:break
  return {'root_id':r['id'],'query':q['query'],'root_fen':b.fen(en_passant='fen'),'full_history_plies':len(r['history']),'binary_sha256':digest(BINARY),'engine_id':e.id,'configured_options':config,'bestmove':best.move.uci(),'active_search_seconds':handler.best-handler.go,'worker_elapsed_before_shutdown':time.monotonic()-started,'last_nonbound_event':unbound[-1] if unbound else None,'last_nonbound_event_matching_bestmove':aligned[-1] if aligned else None,'last_two_distinct_depth_aligned_nonbound_events':list(reversed(distinct)),'bestmove_alignment_issue':not aligned or (bool(unbound) and unbound[-1]['pv'][0]!=best.move.uci()),'events':events,'limits':'3seconds freshprocess/TT Threads1Hash16 noTB, singletonsearchmoves where supplied; nonboundUCI score is finite reported iteration, not proof'}
 finally:
  if e:
   try:e.quit()
   except Exception:e.close()
  logger.removeHandler(handler);handler.close()
def ledger(root):
 p=root/'runs.jsonl';return [json.loads(l) for l in p.read_text().splitlines()] if p.exists() else []
def reference_totals(entry):
 active=cpu=wall=0;starts=[];ends=[]
 for directory,sha in entry.get('programs',{}).items():
  root=pathlib.Path(directory);assert digest(root/'manifest.json')==sha,'reference manifest changed'
  m=read(root/'manifest.json');rows=ledger(root);assert [r['query_index'] for r in rows]==list(range(len(rows))) and len(rows)<=len(m['queries'])
  if len(rows)<len(m['queries']):assert not list(root.glob(f'query-{len(rows):03d}.*')),'reference orphan; inspect explicitly'
  for r in rows:
   for name,h in r['artifact_sha256'].items():assert digest(root/name)==h,'reference artifact changed'
   for key in ('charged_active_seconds','cpu_seconds','process_wall_seconds'):assert math.isfinite(r[key]) and r[key]>=0
   active+=r['charged_active_seconds'];cpu+=r['cpu_seconds'];wall+=r['process_wall_seconds'];starts.append(r['start_utc']);ends.append(r['end_utc'])
 return {'charged_active_seconds':active,'cpu_seconds':cpu,'process_wall_seconds':wall,'start_utc':min(starts) if starts else utc(),'end_utc':max(ends) if ends else utc(),'status':'aggregate includes every success and failure'}
def prepare(candidates,outdir):
 root=pathlib.Path(outdir).resolve()
 with budget.registry_lock(REGISTRY):
  state,used=budget.registry_state(REGISTRY);entry=state['external']['reference'];assert entry['reserved_seconds']==160
  reference_totals(entry);root.mkdir(parents=True,exist_ok=True);assert not any(root.iterdir()),'preserve existing artifacts'
  assert digest(PANEL)==EXPECTED_PANEL
  c=read(candidates);assert c['state']=='FROZEN_DEVELOPMENT_REFERENCE_PAIRS';assert len(c['queries'])==16 and c['nominal_active_seconds']==48
  roots={x['id']:x for x in read(PANEL)}
  for i,q in enumerate(c['queries']):
   assert q['query_index']==i and q['seconds']==3
   b=board_for(roots[q['root_id']]);assert chess.Move.from_uci(q['root_move']) in b.legal_moves
  m={'created_utc':utc(),'candidates_path':str(pathlib.Path(candidates).resolve()),'candidates_sha256':digest(candidates),'driver_sha256':digest(__file__),'runner_sha256':digest(RUNNER),'binary_path':str(BINARY),'binary_sha256':digest(BINARY),'panel_path':str(PANEL),'panel_sha256':EXPECTED_PANEL,'queries':c['queries'],'roots':{q['root_id']:roots[q['root_id']] for q in c['queries']},'nominal_active_seconds':48,'hard_aggregate_reference_seconds':160,'registry':str(REGISTRY),'no_engine_called_by_prepare':True,'source_provenance':'Stockfish19 pinned binary from MSH155; finite analysis only; native predecessor identities in frozen candidate source ledger'}
  write(root/'manifest.json',m);entry.setdefault('programs',{})[str(root)]=digest(root/'manifest.json');budget.save_registry(REGISTRY,state)
  print(json.dumps({'queries':16,'nominal_seconds':48,'manifest':str(root/'manifest.json'),'no_engine_called':True}))
def nextq(outdir,release):
 assert release=='coordinator-slot-released','wait for coordinator explicit release'
 root=pathlib.Path(outdir).resolve()
 with budget.registry_lock(REGISTRY):
  state,global_used=budget.registry_state(REGISTRY);entry=state['external']['reference'];totals=reference_totals(entry)
  assert str(root) in entry['programs'];m=read(root/'manifest.json')
  assert digest(__file__)==m['driver_sha256'] and digest(RUNNER)==m['runner_sha256']
  assert digest(BINARY)==m['binary_sha256'] and digest(PANEL)==m['panel_sha256'] and digest(m['candidates_path'])==m['candidates_sha256']
  runs=ledger(root)
  if len(runs)==len(m['queries']):print('ALL APPROVED QUERIES ATTEMPTED');return
  q=m['queries'][len(runs)];assert totals['charged_active_seconds']+q['seconds']+6<=entry['reserved_seconds'],'reference160 cap with watchdog reserve'
  assert global_used<=state['budget_seconds'],'global budget exhausted'
  base=root/f"query-{q['query_index']:03d}";assert not list(root.glob(base.name+'.*')),'orphan attempt'
  started=utc();write(str(base)+'.json',{'query':q,'root':m['roots'][q['root_id']]})
  # A controller crash releases flock but leaves an invalid aggregate receipt,
  # making the native registry fail closed until orphan work is reconciled.
  pending=pathlib.Path(str(base)+'.pending.json');write(pending,{'pending_reference_attempt':q['query_index'],'start_utc':started})
  entry['receipt_path']=str(pending);entry['receipt_sha256']=digest(pending);budget.save_registry(REGISTRY,state)
  start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN);status=None;p=None
  try:
   with open(str(base)+'.worker.stdout','x') as out,open(str(base)+'.worker.stderr','x') as err:
    p=subprocess.Popen([sys.executable,__file__,'worker',str(base)+'.json'],stdout=out,stderr=err,start_new_session=True)
    try:status=p.wait(timeout=q['seconds']+6)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();status='watchdog'
  except OSError as exc:status='launch_failure';write(str(base)+'.launch-error.json',{'error':str(exc)})
  finally:
   if p:
    try:os.killpg(p.pid,signal.SIGKILL)
    except ProcessLookupError:pass
  wall=time.monotonic()-start;ended=utc();after=resource.getrusage(resource.RUSAGE_CHILDREN);rp=pathlib.Path(str(base)+'.result.json');result=None
  try:
   if status==0:
    result=read(rp);active=result['active_search_seconds'];assert math.isfinite(active) and 0<=active<=wall+1
    assert result['root_id']==q['root_id'] and result['query']==q and result['binary_sha256']==m['binary_sha256'] and result['bestmove']==q['root_move']
  except (ValueError,OSError,KeyError,TypeError,AssertionError):status='malformed_result';result=None
  charged=result['active_search_seconds'] if status==0 else wall
  row={'query_index':q['query_index'],'root_id':q['root_id'],'root_move':q['root_move'],'status':status,'start_utc':started,'end_utc':ended,'charged_active_seconds':charged,'aggregate_charged_seconds':totals['charged_active_seconds']+charged,'process_wall_seconds':wall,'cpu_seconds':after.ru_utime+after.ru_stime-before.ru_utime-before.ru_stime,'result_path':str(rp) if result else None,'artifact_sha256':{p.name:digest(p) for p in root.glob(base.name+'.*')},'panel_sha256':m['panel_sha256'],'binary_sha256':m['binary_sha256'],'driver_sha256':m['driver_sha256']}
  with (root/'runs.jsonl').open('a') as f:f.write(json.dumps(row)+'\n');f.flush();os.fsync(f.fileno())
  # Freeze a new immutable cumulative receipt rather than rewriting earlier ones.
  aggregate=reference_totals(entry);receipt=root/f"charge-after-{q['query_index']:03d}.json";write(receipt,aggregate)
  entry.update({'receipt_path':str(receipt),'receipt_sha256':digest(receipt),'actual_charge_seconds':aggregate['charged_active_seconds'],'over_reservation':aggregate['charged_active_seconds']>entry['reserved_seconds']});budget.save_registry(REGISTRY,state)
  print(json.dumps(row))
  if status!=0:raise SystemExit('failed query retained and charged; no automatic retry')
if __name__=='__main__':
 if sys.argv[1]=='prepare':prepare(sys.argv[2],sys.argv[3])
 elif sys.argv[1]=='next':nextq(sys.argv[2],sys.argv[3])
 elif sys.argv[1]=='worker':
  try:write(str(pathlib.Path(sys.argv[2]).with_suffix(''))+'.result.json',worker(sys.argv[2]))
  except BaseException:traceback.print_exc();raise
 else:raise SystemExit('prepare CANDIDATES OUTDIR | next OUTDIR coordinator-slot-released')
