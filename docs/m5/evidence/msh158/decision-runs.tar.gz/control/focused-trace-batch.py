import subprocess,pathlib,sys
D=pathlib.Path('/tmp/msh158')
for name,binary in [('bishop','passed-extension'),('queen','pv-margin-verify')]:
 for seconds in [5,15]:
  out=D/'runs'/f'{name}-candidate-trace{seconds}'
  subprocess.run([sys.executable,str(D/'runs/runner.py'),'prepare','--panel',str(D/f'trace-{name}.json'),'--binary',str(D/'bin'/binary),'--out',str(out),'--source-revision','frozen-experimental-'+binary,'--registry',str(D/'runs/registry.json'),'--global-budget','2400','--seconds',str(seconds),'--budget',str(seconds+20)],check=True)
  subprocess.run([sys.executable,str(D/'batch.py'),str(out)],check=True)
