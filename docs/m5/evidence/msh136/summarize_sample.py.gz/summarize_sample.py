import re,json,sys
from pathlib import Path
lines=Path(sys.argv[1]).read_text().split('Call graph:\n',1)[1].split('Total number in stack',1)[0].splitlines()
stack=[];totals={};roots=0;leaves=0

def finish():
 global leaves
 n=stack[-1];weight=n['count']-n['children'];assert weight>=0,(weight,n)
 path=[p['name'] for p in stack]
 category=('exchange' if any('chess_conventional8exchange' in p for p in path) else
  'native_queries' if any('SearchCursor4node' in p for p in path) else
  'native_transition_undo' if any('SearchCursor4push' in p or 'SearchCursor3pop' in p for p in path) else
  'evaluation' if any('chess_conventional_eval7dynamic' in p for p in path) else 'other')
 totals[category]=totals.get(category,0)+weight
 if any('Engine10quiescence' in p for p in path):totals['quiescence_inclusive']=totals.get('quiescence_inclusive',0)+weight
 leaves+=weight;stack.pop()
for line in lines:
 m=re.match(r'^([ +!:|.]*)(\d+) (.+?)  \(in ',line)
 if not m:continue
 depth=len(m[1]);count=int(m[2]);name=m[3]
 while stack and stack[-1]['depth']>=depth:finish()
 if stack:stack[-1]['children']+=count
 else:roots+=count
 stack.append({'depth':depth,'count':count,'children':0,'name':name})
while stack:finish()
assert leaves==roots,(leaves,roots)
print(json.dumps({'sampled_stack_weight':roots,'buckets':{k:{'weight':v,'percent':100*v/roots} for k,v in totals.items()},'notes':'First5buckets mutuallyexclusive by deepest broad purpose; quiescence inclusive overlaps. Short mixed-position sample; inlining/partial coverage prevents exact per-operation timings.'},indent=2))
