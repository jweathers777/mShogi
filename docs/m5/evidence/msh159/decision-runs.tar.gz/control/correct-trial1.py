from pathlib import Path
p=Path('crates/mshogi-search/src/chess_conventional_eval.rs');s=p.read_text()
s=s.replace('    let king_defends = distance(f.kings[1 - own], defender.sq) == 1;','''    let king_defends = distance(f.kings[1 - own], defender.sq) == 1;
    let defended = king_defends || f.pawn_attacks[1 - own] & bit(defender.sq) != 0;''')
s=s.replace('&& f.attacks[own] & bit(defender.sq) == 0\n        && (distance(f.kings[own], defender.sq) > 2\n            || king_defends\n            || f.pawn_attacks[1 - own] & bit(defender.sq) != 0)','''&& f.nonking_attacks[own] & bit(defender.sq) == 0
        // Geometric king attacks do not imply a legal capture of a defended
        // bishop. Other attacks still release this conservative guard.
        && (distance(f.kings[own], defender.sq) > 1 || defended)
        && (distance(f.kings[own], defender.sq) > 2 || defended)''')
s=s.replace('// but actual attack by that king does, even with king defense.','// including when adjacent: capturing it would expose the king.')
s=s.replace('assert!(!check("8/8/8/7b/8/4k3/P1KBp3/8 b - - 0 1"));','assert!(check("8/8/8/7b/8/4k3/P1KBp3/8 b - - 0 1"));')
idx=s.index('    #[test]\n    fn independently_derived_term_arithmetic')
s=s[:idx]+'''    #[test]
    fn bishop_blockade_distinguishes_protected_from_capturable_adjacent_bishop() {
        // Bc4 controls a6. Black d5 protects it: Kc3xc4 is illegal, although
        // the king geometrically attacks c4. Removing d5 makes capture legal.
        let protected = position("7k/7p/8/P2p4/2b5/2K5/8/6B1 w - - 0 1");
        let exposed = position("7k/7p/8/P7/2b5/2K5/8/6B1 w - - 0 1");
        let capture = "c3c4".parse().unwrap();
        assert!(!protected.legal_actions().contains(&capture));
        assert!(exposed.legal_actions().contains(&capture));
        for (p, expected) in [(&protected, true), (&exposed, false)] {
            let f = Features::new(p);
            let pawn = f.men.iter().find(|m| m.sq == Square::new(0, 4).unwrap()).unwrap();
            assert_eq!(secure_bishop_blockade(&f, pawn, Square::new(0, 5).unwrap()), expected);
            let mirror = reflect(p);
            let mf = Features::new(&mirror);
            let mp = mf.men.iter().find(|m| m.sq == Square::new(0, 3).unwrap()).unwrap();
            assert_eq!(secure_bishop_blockade(&mf, mp, Square::new(0, 2).unwrap()), expected);
        }
        assert!(evaluate(&protected).white.pawns.end < evaluate(&exposed).white.pawns.end);
    }

'''+s[idx:];p.write_text(s)
