# Trial3b and combined source preparation

No checkout edits, compilation, tests or engine runs. trial3b corrects only the front-control branch: physical bishop occupancy, promotion front, or geometrically undefended intermediate landing required. Current-pawn-pressure branch is unchanged. Added positive/negative color-reflected fixtures holding bishop security constant, and native legal advance assertions for protected empty versus occupied front. Tests are unrun.

Combined source applies the complete exact diff from original baseline to frozen trial2-built-eval.rs onto trial3b using unique verified source anchors. Includes both complete test sets, promotion-race helpers/call, and conservative static-bound comment444. No semantic race edits. Diff relative to trial3b is separately available for review. Source metadata records hashes and each applied diff segment.

Existing rank test remains experimental rather than a proved WDL assertion. Neither source is a validated candidate until parent compilation/tests and bounded decision checks. No further coefficients or future-move credit added.
