# Trial3: current bishop pressure, isolated from race evaluation

Prepared only in /tmp from frozen trial1b. No checkout edits, builds, tests or engines run. Parent should compile/run bishop_pressure and bishop_blockade tests before freezing binary. The matched finite-reference static ranking assertion is an experimental acceptance target, not a verified passing test or rules assertion.

Alternative to front control: opposing bishop currently attacks the advanced strict passer itself and pawn-side geometric attacks do not defend that pawn. Existing material regime and bishop-security guards remain. No coefficient changes. Helper/variable now say restriction; comments describe pressure and blockade. Removed redundant distance>1 predicate because distance>2-or-defended already implies it. Moved the pre-existing runway doc comment back onto its actual function (it had become attached to the newly inserted bishop helper).

New independent controls: Bc1/e3 undefended => pressure; black f4 defending e3 => no pressure; Bc1/e2 => no control and no pressure; all color-reflected. Existing protected/undefended bishop and material-regime controls retained. A separate diagnostic test compares legal Bc1 and Kc2 from the matched after-e3 development state, requiring reference-favored Bc1 to rank higher; unrun and may reject the hypothesis.

Known limitation deliberately preserved: Bc1/e3 -> Bc1/e2 -> Bd2/e2 may produce an evaluation cliff. No future Bd2 credit is authorized. A favorable static ranking alone does not demonstrate root decision benefit; trial1b still selected Bd6 at root. Preserve the matched black reply and ensuing white reply when interpreting results. No score calibration against the reference engine.
